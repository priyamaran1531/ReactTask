import './App.css';
import Index from './pageComponent/Index';
function App() {
  return (
    <div className="App banner-img">
      <Index/>
    </div>
  );
}

export default App;
